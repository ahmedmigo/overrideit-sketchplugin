var CACHE_NAME = "my-pwa-cache-v1";
var urlsToCache = [
  "/",
  "/imgs/close.svg",
  "/imgs/img.svg",
  "/imgs/symbol.svg",
  "/imgs/symbolPlaceHolder.svg",
  "/styles.html",
  "/index.html",
  "/index_bundle.js"
];
self.addEventListener("install", function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      // Open a cache and cache our files
      return cache.addAll(urlsToCache);
    })
  );
});
